
var express= require('express');
var app=express();
var bodyParser = require('body-parser');
var route= require('./route.js');

app.use(bodyParser.urlencoded({ extended: true }));


var cookieParser= require('cookie-parser');


app.use(cookieParser());


app.use(express.static(__dirname + '/public'));

app.set('view engine','pug');
app.set('views','./views');



app.post('/HomeePage',function(req,res){
    var Firstname='First Name: '+(req.cookies.userdata.Firstname);
    var Lastname='Last Name: '+(req.cookies.userdata.Lastname);
    var Email='E-Mail: '+(req.cookies.userdata.Email);
    var DOB='Date Of Birth: '+(req.cookies.userdata.DOB);
    var PhNum='Phone Number: '+(req.cookies.userdata.PhNumber);
    var Name=Firstname+' , '+Lastname+' , '+Email+' , '+DOB+' , '+PhNum;
    res.send(Name);

});


app.get('/LoginPage',function (req,res) {
    res.render('LoginPage');
});

app.post('/LoginPage',function (req,res){
    console.log(req.body);
    if(req.body.Emaill===req.cookies.userdata.Emaill || req.body.Passwordd===req.cookies.userdata.Passwordd) {
        res.redirect('/HomeePage');
    }
    else res.send('Invalid credentials');
});



app.get('/RegistrationnPage',function (req,res) {
    res.render('RegistrationnPage');

});





app.post('/RegistrationnPage',function(req,res) {
    console.log(req.body);
    const FirstNamee = req.body.FirstNamee;
    const LastNamee = req.body.LastNamee;
    const EMaill = req.body.EMaill;
    const DOBB = req.body.DOBB;
    const PhNum = req.body.PhNum;
    const Passwordd = req.body.Passwordd;
    let user={Firstname: FirstNamee, Lastname: LastNamee, Email: EMaill,DOB: DOBB,PhNumber: PhNum, Password: Passwordd};
    res.cookie("userdata",user);
    res.redirect('/LoginPage');
});




//let users= {
  //  name: "padma",
  //  email: "tejadevarapalli47@gmail.com"
//};


app.get('/',(req,res)=>{
    res.redirect('/RegistrationnPage');
});



app.listen(3000);

